<?php

namespace App\Http\Controllers\Hr;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\RegisterData;
use App\Models\ExperienceModel;
use App\Models\ExperienceApprovalModel;
use App\Models\HrModel;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Auth\MailController;
use Symfony\Component\Console\Output\ConsoleOutput;
use Illuminate\Support\Str;
use Illuminate\Support\Facades\Mail;
use App\Mail\EmployeerRegisterOtp;

// use Session;
use App\Models\User;
// use Hash;
use Illuminate\View\View;
use Illuminate\Http\RedirectResponse;

class HrController extends Controller
{
    /**
     * Write code on Method
     *
     * @return response()
     */
    public function index(): View
    {
        return view('hr.login');
    }

    /**
     * Write code on Method
     *
     * @return response()
     */
    public function registration(): View
    {
        return view('hr.registration');
    }

    public function storeStep1(Request $request)
    {
        // Validate incoming data
        $validator = Validator::make($request->all(), [
            'company_name' => 'required|string|max:255',
            'hr_name' => 'required|string|max:255',
            'hr_email' => 'required|email|unique:hr_data,hr_email',
            'hr_phone' => 'required|digits:10|unique:hr_data,hr_phone',
            'hr_password' => 'required|min:6',
        ]);

        if ($validator->fails()) {
            return response()->json(['errors' => $validator->errors()], 422);
        }

        // Generate Base HR Unique ID
        $companyPrefix = substr(preg_replace('/\s+/', '', $request->company_name), 0, 3); // First 3 letters of company name (without spaces)
        $firstName = explode(' ', trim($request->hr_name))[0]; // Extract first name from hr_name
        $baseHrUniqueId = strtolower($companyPrefix . '_hr_' . $firstName); // Base unique ID

        // Ensure Unique HR Unique ID
        $hrUniqueId = $baseHrUniqueId;
        $count = 1;
        while (HrModel::where('hr_unique_id', $hrUniqueId)->exists()) {
            $hrUniqueId = $baseHrUniqueId . $count; // Append numeric suffix
            $count++;
        }

        // Generate OTP (6-digit random number)
        $otp = rand(100000, 999999);
        $to = $request->hr_email;
        $subject = "OTP Employer Registration";

        // Store Data in Database
        $hr = HrModel::create([
            'company_name' => $request->company_name,
            'hr_name' => $request->hr_name,
            'hr_email' => $request->hr_email,
            'hr_phone' => $request->hr_phone,
            'hr_password' => Hash::make($request->hr_password), // Use Hash::make
            'register_otp' => $otp, // Store OTP
            'is_register_verified' => false, // Not verified yet
            'hr_unique_id' => $hrUniqueId, // Store unique ID
        ]);
        // dd($hr);
        // Send OTP Email
        Mail::to($to)->send(new EmployeerRegisterOtp($subject, $otp));
        return response()->json([
            'success' => true,
            'message' => 'Step 1 data saved. OTP sent.',
            'hr_email' => $hr->hr_email, // Return email instead of ID
            'hr_unique_id' => $hrUniqueId, // Return the unique ID for confirmation
        ]);
    }

    public function storeStep2(Request $request)
    {
        $validatedData = $request->validate([
            'hr_email' => 'required|email|exists:hr_data,hr_email', // Ensure HR email exists
            'hr_aadhar' => 'required|string|max:12|unique:hr_data,hr_aadhar',
            'hr_pan' => 'required|string|max:10|unique:hr_data,hr_pan',
            'hr_dob' => 'required|date',
           
        ]);

        // Find the HR record by email
        $hrData = HrModel::where('hr_email', $validatedData['hr_email'])->first();

        if ($hrData) {
            // Update existing HR record
            $hrData->update([
                'hr_aadhar' => $validatedData['hr_aadhar'],
                'hr_pan' => $validatedData['hr_pan'],
                'hr_dob' => $validatedData['hr_dob'],
            ]);

            return response()->json([
                'success' => true,
                'message' => 'HR step2 successfully!',
                'data' => $hrData,

            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'HR email not found!',
        ], 404);
    }

    public function storeStep3(Request $request)
    {
        $validatedData = $request->validate([
            'hr_email' => 'required|email|exists:hr_data,hr_email', // Ensure HR email exists
            'reporting_manager_mail' => 'required|email',
            'reporting_manager_name' => 'required|string|max:255',
            'reporting_manager_contact' => 'required|digits:10',
            'company_website' => 'required|max:255',
        ]);

        // Find the HR record by email
        $hrData = HrModel::where('hr_email', $validatedData['hr_email'])->first();

        if ($hrData) {
            // Update existing HR record
            $hrData->update([
                'reporting_manager_mail' => $validatedData['reporting_manager_mail'],
                'reporting_manager_name' => $validatedData['reporting_manager_name'],
                'reporting_manager_contact' => $validatedData['reporting_manager_contact'],
                'company_website' => $validatedData['company_website'],
            ]);

            return response()->json([
                'success' => true,
                'message' => 'HR step3 successfully!',
                'data' => $hrData,

            ]);
        }

        return response()->json([
            'success' => false,
            'message' => 'HR email not found!',
        ], 404);
    }

    public function store(Request $request)
    {
        return response()->json([
            'success' => true,
            'message' => 'HR Registered successfully!',
            'redirect' => url('hr-login')
        ]);
        // return response()->json([
        //     'success' => false,
        //     'message' => 'HR email not found!',
        // ], 404);
    }

    public function login(Request $request)
    {
        $validatedData = $request->validate([
            // 'hr_unique_id' => 'required|string|exists:hr_data,hr_unique_id',
            'hr_unique_id' => 'required|string',
            'hr_password' => 'required|string|min:6',
        ]);

        // ✅ Find user
        // $user = HrModel::where('hr_unique_id', $validatedData['hr_unique_id'])->first();
        $user = HrModel::where('hr_unique_id', $validatedData['hr_unique_id'])->orWhere('hr_email', $validatedData['hr_unique_id'])->first();

        // ✅ Check if user exists and password is correct
        if (!$user || !Hash::check($validatedData['hr_password'], $user->hr_password)) {
            return response()->json([
                'success' => false,
                'message' => 'Invalid unique ID or password!'
            ], 401);
        }

        // ✅ Store user in session
        session(['user' => $user]);

        return response()->json([
            'success' => true,
            'message' => 'HR Login successful!',
            'data' => $user,
            'redirect' => url('hrdashboard')
        ]);
    }


    public function hrdashboard()
    {

        // Check if user is logged in via session
        if (!session()->has('user')) {
            return redirect()->route('hr-login-page')->with('error', 'Please login first.');
        }

        // Get logged-in user from session
        $user = session('user');
        // dd($user);
        return view('hr.dashboard', compact('user'));
    }

    public function hrlogout(Request $request)
    {
        // Clear session data
        Session::forget('user');
        Session::flush();

        return response()->json([
            'success' => true,
            'message' => 'Hr Logged out successfully!',
            'redirect' => url('/')
        ]);
    }

    public function viewApprovalRequests()
    {
        // Check if session data exists
        if (!session()->has('user')) {
            return response()->json(['error' => 'User not authenticated'], 401);
        }

        // Retrieve the logged-in HR's email from the session
        $hrEmail = session('user')->hr_email; // Ensure the column name is correct
        // Fetch approval requests for this HR
        $requests = DB::table('user_experience_approval')
            ->join('user_experience', 'user_experience.id', '=', 'user_experience_approval.experience_id')
            ->where('user_experience_approval.approver_email', $hrEmail)
            ->select(
                'user_experience.*',
                'user_experience_approval.id as approval_id',
                'user_experience_approval.approval_status',
                'user_experience_approval.status_note'
            )
            ->get();
        //   dd( $requests);
        return response()->json($requests);
    }


    public function addApprovalAndStatusByEmployer(Request $request)
    {
        $validatedData = $request->validate([
            // 'eimagerId' => 'required|string|max:200',
            'experience_id' => 'required|int|max:200',
            'approval_status' => 'required|string|max:1024',
            'status_note' => 'required|string|max:1024',
        ]);


        $hruniqueid = session('user')->hr_unique_id;
        $experience_id = $request->input('experience_id');

        $employee_details = DB::select('select first_name, email, unique_id from register_data where unique_id=(select eimager_id from user_experience where id = ?)', [$experience_id]);
        $user_details = DB::select('select hr_name, hr_email from hr_data where hr_unique_id=?', [$hruniqueid]);

        // Store data in the database
        $experience = ExperienceApprovalModel::create([
            'experience_id' => $validatedData['experience_id'],
            'approval_status' => $validatedData['approval_status'],
            'status_note' => $validatedData['status_note'],
            'approver_email' => session('user')->hr_email,
        ]);


        // $employee_name = $user_details[0]->first_name;
        // $employee_eimager_id = $user_details[0]->unique_id;

        // $to = $approver_email;
        // $from = 'eimager@gmail.com';
        // $subject = 'Experience Approved';

        // MailController::sendReviewRequestMail($to, $from, $subject, $employee_name, $employee_eimager_id);

        return response()->json([
            'success' => true,
            'message' => 'Request has been created.',
            'data' => $experience
        ]);
    }

    public function showProfile()
    {

        if (!session()->has('user')) {
            return redirect()->route('login')->with('error', 'You need to login first');
        }

        $hruniqueid = session('user')->hr_unique_id;
        $hr = HrModel::where('hr_unique_id', $hruniqueid)->first();

        if (!$hr) {
            return redirect()->route('dashboard')->with('error', 'HR profile not found');
        }

        $hr->hr_aadhar = str_repeat('*', strlen($hr->hr_aadhar) - 4) . substr($hr->hr_aadhar, -4);
        $hr->hr_pan = str_repeat('*', strlen($hr->hr_pan) - 4) . substr($hr->hr_pan, -4);


        return view('hr.profile', compact('hr'));
    }

    public function showEmployeeProfile()
    {
        if (!session()->has('user')) {
            return redirect()->route('login')->with('error', 'You need to login first');
        }

        $hr = session('user');


        return view('hr.employeeprofile', compact('hr'));
    }

    public function employeeExperienceByEimagerId(Request $request)
    {
        $output = new ConsoleOutput();
        $eimager_id = $request->input('eimager_id');
        $employee_eimager_id = $request->input('employee_eimager_id');

        // $allExperience = ExperienceModel::where('eimager_id', $eimager_id)->orderby('created_at','DESC')->get();

        $allExperience = DB::select('SELECT ue.*, (select approval_status from user_experience_approval where experience_id=ue.id ORDER by created_at desc LIMIT 1) as approval_status, (select status_note from user_experience_approval where experience_id=ue.id ORDER by created_at desc LIMIT 1) as status_note FROM user_experience as ue WHERE eimager_id= ?', [$employee_eimager_id]);

        $user = HrModel::where('hr_unique_id', $eimager_id)->first();

        $data = [];
        foreach ($allExperience as $exp) {
            $data[] = [
                'exp_id'             => $exp->id,
                'company_name'             => $exp->company_name,
                'designation'            => $exp->designation,
                'projects' => $exp->projects,
                'start_date'       => $exp->start_date,
                'end_date'       => ($exp->end_date == null ? 'Still Working' : $exp->end_date),
                'ctc'       => $exp->ctc,
                'in_hand'       => $exp->in_hand,
                'roles_responsibility'       => $exp->roles_responsibility,
                'approval_status'       => $exp->approval_status,
                'status_note'       => $exp->status_note,
                'is_approval_visible' => ($exp->company_name === $user->company_name ? true : false)
            ];
        }

        return response()->json([
            'success' => true,
            'message' => 'success',
            'data' => $data
        ]);
    }

    public function searchEmployeeProfile(Request $request)
    {
        if (!session()->has('user')) {
            return redirect()->route('login')->with('error', 'You need to login first');
        }

        $eimager_id = $request->input('eimagerId');
        $aadhar_number = $request->input('aadharNumber');
        $pan_number = $request->input('panNumber');
        $email = $request->input('email');
        $user = RegisterData::where('unique_id', $eimager_id)->orWhere('aadhar_number', $aadhar_number)->orWhere('pan_number', $pan_number)->orWhere('email', $email)->first();

        if ($user) {
            $user->aadhar_number = str_repeat('*', strlen($user->aadhar_number) - 4) . substr($user->aadhar_number, -4);
            $user->pan_number = substr($user->pan_number, 5) . str_repeat('*', strlen($user->pan_number) - 5);
            $user->phone_number = substr($user->phone_number, 0, 3) . str_repeat('*', (strlen($user->phone_number) - 3)) . substr($user->phone_number, -3);
            $user->email = Str::mask($user->email, '*', 2, 7);

            return response()->json([
                'success' => true,
                'message' => 'success',
                'data' => $user
            ]);
        } else {
            return response()->json([
                'success' => false,
                'status' => 'error',
                'message' => 'User Not found. Please enter correct input'
            ]);
        }
    }

    public function sendOtpRequest(Request $request)
    {
        if (!session()->has('user')) {
            return redirect()->route('login')->with('error', 'You need to login first');
        }

        $eimager_id = $request->input('eimagerId');
        $employeeEmail = $request->input('employeeEmail');
        $employeeEImagerId = $request->input('employeeEImagerId');
        $employee = RegisterData::where('unique_id', $employeeEImagerId)->first();
        $user = HrModel::where('hr_unique_id', $eimager_id)->first();
        // dd($user) ;   
        $user_name = $employee->first_name;
        $eimager_id = $employee->unique_id;
        $employee_eimager = $user->hr_unique_id;
        $to = $user->hr_email;
        $subject = 'OTP for Employee Profile';
        $otp = rand(10000, 99999);
        DB::table('hr_data')
            ->where('hr_unique_id', $employee_eimager)  // find your user by their email
            ->update(array('employee_profile_otp' => $otp));

        MailController::sendEmployeeProfileOtp($to, $subject, $otp);
        return response()->json([
            'success' => true,
            'message' => 'success',
            'data' => $user
        ]);
    }

    public function approveExperienceByEmployer(Request $request)
    {
        $request->validate([
            'id' => 'required|integer',  // Update to match your table column
            'approval_status' => 'required|in:pending,approved,rejected',  // Ensure valid status
            'status_note' => 'nullable|string'
        ]);

        $approval = ExperienceApprovalModel::find($request->id); // Fetch by ID

        if (!$approval) {
            return response()->json(['message' => 'Approval request not found'], 404);
        }

        // Update fields
        $approval->approval_status = $request->approval_status;
        $approval->status_note = $request->status_note;
        $approval->save();

        return response()->json(['message' => 'Approval status updated successfully']);
    }


    public function sendApprovalOrRejectionRequest(Request $request)
    {
        if (!session()->has('user')) {
            return redirect()->route('login')->with('error', 'You need to login first');
        }

        $eimager_id = $request->input('eimagerId');

        $user = HrModel::where('hr_unique_id', $eimager_id)->first();
        $to = $user->hr_email;
        $subject = 'OTP for Experience Approval/Rejection';
        $otp = rand(10000, 99999);
        DB::table('hr_data')
            ->where('hr_unique_id', $eimager_id)
            ->update(array('employee_approval_rejection_otp' => $otp));

        MailController::sendExperienceApprovalRejectionOtp($to, $subject, $otp);
        return response()->json([
            'success' => true,
            'message' => 'success',
            'data' => $user
        ]);
    }



    public function approvalRejectionOtpVerification(Request $request)
    {
        $otp = $request->input('otp');

        // Check if OTP exists in hr_data table
        $exists = DB::table('hr_data')->where('employee_approval_rejection_otp', $otp)->exists();

        if ($exists) {
            return response()->json(['success' => true, 'message' => 'OTP Verified Successfully']);
        } else {
            return response()->json(['success' => false, 'message' => 'Invalid OTP']);
        }
    }


    public function verifyOtp(Request $request)
    {
        $otp = $request->input('otp');

        // Check if OTP exists in hr_data table
        $exists = DB::table('hr_data')->where('employee_profile_otp', $otp)->exists();

        if ($exists) {
            return response()->json(['success' => true, 'message' => 'OTP Verified Successfully']);
        } else {
            return response()->json(['success' => false, 'message' => 'Invalid OTP']);
        }
    }

    public function verifyregisterOtp(Request $request)
    {
        $request->validate([
            'hr_email' => 'required|email',
            'otp' => 'required|digits:6',
        ]);

        $hr = HrModel::where('hr_email', $request->hr_email)
            ->where('register_otp', $request->otp)
            ->first();

        if ($hr) {
            $hr->update(['is_register_verified' => true]); // Mark as verified
            return response()->json(['success' => true, 'message' => 'OTP Verified! Proceed to the next step.']);
        } else {
            return response()->json(['success' => false, 'message' => 'Invalid OTP! Please try again.']);
        }
    }

    public function addstore(Request $request)
    {
        try {
            $validated = Validator::make($request->all(), [
                'hr_name' => 'required|string|max:255',
                'hr_email' => 'required|email|unique:hr_data,hr_email',
                'hr_phone' => 'required|digits:10|unique:hr_data,hr_phone',
                'hr_password' => 'required|string|min:6',
                'company_name' => 'required|string|max:255',
                'reporting_manager_mail' => 'required|email',
                'hr_aadhar' => 'required|string|max:20',
                'hr_pan' => 'required|string|max:20',
                'hr_dob' => 'required|date',
                'reporting_manager_name' => 'required|string|max:255',
                'reporting_manager_contact' => 'required|string|max:20',
                'company_website' => 'required',
            ]);

            if ($validated->fails()) {
                return response()->json([
                    'status' => 'error123345',
                    'errors' => $validated->errors(),
                ], 422);
            }

            // Generate unique HR ID
            $companyPrefix = substr(preg_replace('/\s+/', '', $request->company_name), 0, 3);
            $firstName = explode(' ', trim($request->hr_name))[0];
            $baseHrUniqueId = strtolower($companyPrefix . '_hr_' . $firstName);
            $hrUniqueId = $baseHrUniqueId;
            $count = 1;
            while (HrModel::where('hr_unique_id', $hrUniqueId)->exists()) {
                $hrUniqueId = $baseHrUniqueId . $count;
                $count++;
            }

            // Insert into DB
            $hr = HrModel::create([
                'hr_name' => $request->hr_name,
                'hr_email' => $request->hr_email,
                'hr_phone' => $request->hr_phone,
                'hr_password' => Hash::make($request->hr_password),
                'company_name' => $request->company_name,
                'reporting_manager_mail' => $request->reporting_manager_mail,
                'hr_aadhar' => $request->hr_aadhar,
                'hr_pan' => $request->hr_pan,
                'hr_dob' => $request->hr_dob,
                'reporting_manager_name' => $request->reporting_manager_name,
                'reporting_manager_contact' => $request->reporting_manager_contact,
                'company_website' => $request->company_website,
                'hr_unique_id' => $hrUniqueId,
            ]);

            return response()->json([
                'status' => 'success',
                'hr_unique_id' => $hr->hr_unique_id,
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'status' => 'error',
                'message' => $e->getMessage(),
            ], 500);
        }
    }
}
